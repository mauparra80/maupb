/*
Mauricio Parra
CS 3345.003
Fall 2017
Project 2: design a magazine link list to store magazines
 */
package Main;


public class LinkedList<T extends IDedObject> 
{
    private Node<T> head;//set the head of list
    
    public LinkedList()//cuntructor generates an empty list
    {
        head = null;
    }
    
    public void makeEmpty() //empties the linked list
    {
        if (head != null)//if list is not empty, empty
        {
            head = null;
        }
    }
    
    public T findID(int id)//finds id and returns object of id
    {
        Node<T> temp = head;//temp to store node
        
        if (head == null)
            return null;
        while (temp != null)//while node is present
        {
        if (temp.n.getID() == id)//if id of node is found
            return temp.n;
        else if (temp.n.getID() != id)//if id is not found
            temp = temp.next;//make temp next node
        }       
        return null;//if not found return null
    }
    
    public boolean insertAtFront(Node<T> x)//method to insert a node at front
    {
        Node<T> temp = head;
        if (head == null)//if list is empty, make node head
        {
            head = x;
            return true;
        }
        else
        {
            while (temp != null)//
            {
                if(temp.n.getID() == x.n.getID())//if id already exists
                    return false;
                else
                    temp = temp.next;//else, keep checking next node
            }
        }
        x.next = head;//if id does not exist place node at head
        head = x;
        return true;
    }
    
    public T deleteFromFront()//method to delete first node
    {
        Node<T> temp = head;
        if (head == null)
            return null;
        else 
        {
            head = head.next;//if head exists make next head and return head
            return temp.n;
        }
    }
    
    public T delete(int ID)//method to delete any id
    {
        Node<T> temp = head;
        Node<T> beforeTemp = head;//second temp before the once being deleted
        if (head == null)
            return null;
        if (head.n.getID() == ID)//if id is head
        {
            temp = head;//delete head and make next head
            head.next = head;
            return temp.n;
        }
        else
        {
            temp = temp.next;
            while (temp!= null)//find id return and delete node
            {
               if(temp.n.getID() == ID)
               {
                   beforeTemp.next = temp.next;
                   return temp.n;
               }
               else
               {
                   temp = temp.next;
                   beforeTemp = beforeTemp.next;
               }
            }
        }
       return null; 
    }
    
    public void printAllRecords()//method to print all nodes
    {
        Node<T> temp = head;
        if (head == null)//if empty 
            System.out.println("There are no stored magazines.");
        else
        {
            while(temp != null)//itirate and print
            {
            temp.n.printID();
            temp = temp.next;
            }
        }
    }
    
    public static class Node<T>//node class
    {
        T n;//node of object t
        Node<T> prev;//prev pointer
        Node<T> next;//next pointer
        public Node()//empty constructor
                {
                }
        public Node(T n)//constructor of type n
        {
            this.n = n;
        }
    }
}
