/*
Mauricio Parra
CS 3345.003
Fall 2017
Project 2: design a magazine link list to store magazines
 */
package Main;


public interface IDedObject //interface for Magazine to use
{
    int getID();//abstract methods defined in Magazine
    void printID();
}
