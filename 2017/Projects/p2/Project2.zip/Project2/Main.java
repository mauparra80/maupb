/*
Mauricio Parra
CS 3345.003
Fall 2017
Project 2: design a magazine link list to store magazines
 */
package Main;
import java.util.*;

public class Main 
{
    public static void main(String []args)
    {
        Scanner kb = new Scanner(System.in);//open keboard for input
        LinkedList<Magazine> list = new LinkedList<>();//create our list
        int choice = 7;//variable for input
        int ID = 0;//ID variable used many times
        
        boolean exit = false;
        while(exit == false)//exit condition false
        {
        System.out.println("\n\nWelcome to Magazine Mania!"
            + "\n1. Make Empty"
            + "\n2. Find ID"
            + "\n3. Insert At Front"
            + "\n4. Delete From Front"
            + "\n5. Delete ID"
            + "\n6. Print All Records"
            + "\n7. Done");
        
        choice = CheckID(kb);//get input to choice
        
        switch(choice)
        {
            case 1://make Empt
            {
                list.makeEmpty();
                System.out.println("Done!");
                break;
            }
            case 2://Find ID
            {
                System.out.println("\nWhat ID would you like to find?");
                ID = CheckID(kb);
                Magazine m = list.findID(ID);//will return null for not found
                if (m == null)              //or node for found
                    System.out.println("Magazine not found");
                else
                    m.printID();
                break;
            }
            case 3://Insert at front
            {
                String mName;
                String mPublisher;//get all information from user
                System.out.println("\nMagazine ID: ");
                ID = CheckID(kb);
                System.out.println("Magazine Name: ");
                mName = CheckString(kb);
                System.out.println("Magazine Publisher: ");
                mPublisher = CheckString(kb);
                Magazine m = new Magazine(ID,mName,mPublisher);//create object
                LinkedList.Node<Magazine> n = new LinkedList.Node<>(m);//make node of type object
                boolean result = list.insertAtFront(n);
                if(result == false)
                    System.out.println("ID already Exists");//if return false, id exists
                else
                    System.out.println("Done!");//if return true, added
                break;
            }
            case 4://Delete From Front
            {
                Magazine m = list.deleteFromFront();
                if(m == null)
                    System.out.println("There are no magazines.");//return null, empty
                else
                    m.printID();//return object, print
                break;
            }
            case 5://Delete ID
            {
                System.out.println("\nWhat Magazine ID would you like to delete?");
                ID = CheckID(kb);
                Magazine m = list.delete(ID);
                if(m == null)
                    System.out.println("Magazine not found.");//return null, id not found
                else
                    m.printID();//return object, print
                break;
            }
            case 6://Print All Records
            {
                list.printAllRecords();
                break;
            }
            case 7://done
            {
                exit = true;
                break;
            }
                
        }
        
        
        }
    }
    
    public static int CheckID(Scanner kb)//method to error check int
    {
        int tempInt = 0;
        boolean error = true;
        while(error == true)
        {
        try//try to take int
        {
            tempInt = kb.nextInt();
            error = false;
        }
        catch (Exception e)//if not integer, print error and try again
        {
                System.out.println("ERROR: not an integer \nTry again:");
                kb.next();//if not integer print error and clear kb.
        }
        }
        return tempInt;//return input
    }
    public static String CheckString(Scanner kb)//method to error check String(not needed)
    {
        String tempString = "";
        boolean error = true;
        while(error == true)
        {
            try//try to take String
            {
                tempString = kb.next();
                error = false;        
            }
            catch (Exception e)//if not String, print error and try again
            {
                System.out.println("ERROR: not a String \nTry again:");
                kb.next();
            }
        }
        return tempString;//return String
    }
}

