/*
Mauricio Parra
CS 3345.003
Fall 2017
Project 2: design a magazine link list to store magazines
 */
package Main;


public class Magazine implements IDedObject//our object we will use
{
    private int magazineID;//variable declaration
    private String magazineName;
    private String publisherName;
    
    public Magazine()//empty constructor
    {
    }
    
    public Magazine(int id, String name, String pName)//const that sets variables
    {
        magazineID = id;
        magazineName = name;
        publisherName = pName;
    }
    
    @Override
    public int getID()//returns id
    {   
    return magazineID;
    }
    
    @Override
    public void printID()//prints contents of object
    {
        System.out.println("\nID: " + magazineID + "\nMagazine Name: "
                + magazineName + "\nPublisher Name: " + publisherName);
    }
    
    
    
}
