/*
 Mauricio Parra
CS 3345.003
Fall 2017
Project 4. Red black tree with insert and print functions
 */


import java.util.*;
public class RedBlackTree <E extends Comparable<E>>
{
    static boolean RED = false;//
    static boolean BLACK = true;
    static Node root;

    //insert function to insert and balance tree
    public boolean insert(E element) throws NullPointerException
    {
        if (element == null)// if element given is null
            return false;

        Node<E> n = new Node<>(element);//creating node to put element in

        if (root == null)//if tree is empty
        {
            root = n;
            return true;
        }

        Node<E> cur = root;//set current
        boolean exit = true;
        while (exit)//insert node
        {
            int comp = element.compareTo(cur.element);//compare cur to new element
            if (comp < 0)//element goes to left
            {
                if(cur.leftChild == null)//if next spot is null, insert node
                {
                    cur.leftChild = n;
                    adjust(n);//adjust tree
                    return true;
                }
                else
                    cur = cur.leftChild;
            }
            else if (comp > 0)//element goes to right
            {
                if(cur.rightChild == null)//if next spot is null, insert node
                {
                    cur.rightChild = n;
                    adjust(n);//balance tree
                    return true;
                }
                else
                    cur = cur.rightChild;
            }
            else if (comp == 0)//if node already exists. return false
            {
                exit = false;
                return false;
            }
        }

        return false;
    }

    //contains function to check if node exists within the tree
    public boolean contains(Comparable<E> object)
    {
        if (object == null || root == null)
            return false;
        return root.contains(object);
    }

    @Override
    public String toString()//overridden tostring to return in order traversal as string
    {
        if (root == null)
            return"";

        Node<E> cur = root;//set cur at root
        StringJoiner sj = new StringJoiner("\t", "[", "]");//create joiner to keep track of string
        //String sj = "";
        sj = toStringHelper(cur, sj);//call helper
        String finals = sj.toString();//convert joiner to string
        return finals;
    }
    //helper method for tostring
    private StringJoiner toStringHelper(Node<E> cur, StringJoiner sj)
    {
        if (cur == null)//end statement
            return sj;
        toStringHelper(cur.leftChild,sj);//check left
        if(cur.color == BLACK)//if node is black,  print normal
        {
            sj.add(cur.element + "");
        }
        else//if node is red, print with asterisk
            sj.add(cur.element + "*");
        toStringHelper(cur.rightChild,sj);//check right
        return sj;
    }

    //extra method to adjust tree
    private void adjust(Node<E> n)
    {

        if (n != null && n != root && n.isRed(n.getParent(n)))//if there is a problem
        {
            if (n.isRed(n.siblingOf(n.parentOf(n))))//if sibling of parent is red
            {
                n.parentOf(n).color = BLACK;//make parent black
                n.siblingOf(n.parentOf(n)).color = BLACK;//make sibling of parent black
                n.grandparentOf(n).color = RED;//but make grandparent red
                adjust(n.grandparentOf(n));//check again
            }

            else if(n.grandparentOf(n) != null)//if grandparent exsists
            {
            if(n.parentOf(n) == n.grandparentOf(n).leftChild)//if parent is left child of gp
            {
                if (n == n.parentOf(n).rightChild)//if n is right, rotate left
                    rotateLeft(n = n.parentOf(n));
                n.parentOf(n).color = BLACK;//recolor
                n.grandparentOf(n).color = RED;
                rotateRight(n.grandparentOf(n));//roate gp right
            }
            }
            else if (n.grandparentOf(n) != null)
            {
            if(n.parentOf(n) == n.grandparentOf(n).rightChild)//if parent is right child of gp
            {
                if (n == n.parentOf(n).leftChild)//if n is left child
                    rotateRight(n = n.parentOf(n));//rotate right
                n.parentOf(n).color = BLACK;//recolor
                n.grandparentOf(n).color = RED;
                rotateLeft(n.grandparentOf(n));
            }
            }
        }
        root.color = BLACK;//always make root black
    }


    private void rotateLeft(Node<E> n)//helper function to rotate left
    {
        if (n.rightChild == null)
            return;
        Node<E> oldRight = n.rightChild;//temp for right child
        n.rightChild = oldRight.leftChild;
        if (n.getParent(n) == null)//if parent is null
            root = oldRight;
        else if (n.getParent(n).leftChild == n)//if n is left of parent
            n.getParent(n).leftChild = oldRight;
        else
            n.getParent(n).rightChild = oldRight;
        oldRight.leftChild = n;
    }

    private void rotateRight(Node<E> n)//helper function to rotate right
    {
        if (n.leftChild == null)
            return;
        Node<E> oldLeft = n.leftChild;
        n.leftChild = oldLeft.rightChild;
        if (n.getParent(n) == null)
            root = oldLeft;
        else if (n.getParent(n).leftChild == n)//if n is left child
            n.getParent(n).leftChild = oldLeft;
        else
            n.getParent(n).rightChild = oldLeft;//if n is right child
        oldLeft.rightChild = n;
    }





    public static class Node<E extends Comparable<E>>
    {
        E element;
        Node leftChild;
        Node rightChild;
        Node parent;
        boolean color;

        private Node(E newElement)//constructor
        {
            element = newElement;
            color = RED;
        }


        private boolean isRed(Node n)//return true if red
        {
            if (n != null && color == RED)
                return true;
            else
                return false;
        }


        private Node getParent(Node<E> n)//helper to return parent of n
        {
            return getParentHelper(root,n);
        }
        private Node getParentHelper(Node<E> cur, Node<E> n)
        {
            if (n == root || cur == null)//if n is root or root is null
                return null;
            else
            {
                if (cur.leftChild == n || cur.rightChild == n)//if cur is parent of n
                    return cur;
                else
                {
                    int comp = cur.element.compareTo(n.element);//else compare
                    if (comp < 0)//if n is on right of cur, shift right
                    {
                        return getParentHelper(cur.rightChild,n);
                    }
                    else//else shift left
                        return getParentHelper(cur.leftChild,n);
                }
            }
        }

        private Node parentOf(Node<E> n)//to return parent of n
        {
            if(n == null)
                return null;
            else
                return n.getParent(n);
        }
        private Node grandparentOf(Node<E> n)//to return grandparent of n
        {
            if(n == null || n.getParent(n) == null)
                return null;
            else
            {
                n = getParent(n);
                return n.getParent(n);
            }
        }

        private Node siblingOf(Node<E> n)// to return sibling of n
        {
            if (n.getParent(n) == null || n.getParent(n).rightChild == null || n.getParent(n).leftChild == null)
                return null;//if not null
            else
            {
                if(n.getParent(n).leftChild != n)//if n is right child return left child
                    return n.getParent(n).leftChild;
                else
                    return n.getParent(n).rightChild;//else return right child
            }
        }

        private boolean contains(Comparable<E> object)//helper function for contains
        {
           int comp = object.compareTo(element);//compareto
           if(comp < 0)//if n is left of cur
               return leftChild.contains(object);
           else if(comp > 0 )//if n is right of cur
               return rightChild.contains(object);
           else
               return true;
        }


    }

}



